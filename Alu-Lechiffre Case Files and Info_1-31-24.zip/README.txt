# AluChiffre
 AluChiffre


Screws:

Case screws: M3 10mm x4 https://www.mcmaster.com/90991A114/
Plate screws: m2 6mm x8 https://www.mcmaster.com/90910A922/